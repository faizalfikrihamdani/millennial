<!-- <?php $__env->startSection('title','Home'); ?> -->
<?php $__env->startSection('utama'); ?>
<main>

    <!-- slider Area Start -->
    <div class="slider-area ">
        <!-- Mobile Menu -->
        <div class="slider-active">
            <div class="single-slider slider-height" data-background="assets2/img/hero/h1_hero.jpg">
                <div class="container">
                    <div class="row d-flex align-items-center justify-content-between">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 d-none d-md-block">
                            <div class="hero__img" data-animation="bounceIn" data-delay=".4s">
                                <img src="assets2/img/hero/hero_man.png" alt="">
                            </div>
                        </div>
                        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-8">
                            <div class="hero__caption">
                                <span data-animation="fadeInRight" data-delay=".4s">60% Discount</span>
                                <h1 data-animation="fadeInRight" data-delay=".6s">Winter <br> Collection</h1>
                                <p data-animation="fadeInRight" data-delay=".8s">Best Cloth Collection By 2020!</p>
                                <!-- Hero-btn -->
                                <div class="hero__btn" data-animation="fadeInRight" data-delay="1s">
                                    <a href="/industries" class="btn hero-btn">Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider slider-height" data-background="assets2/img/hero/h1_hero.jpg">
                <div class="container">
                    <div class="row d-flex align-items-center justify-content-between">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 d-none d-md-block">
                            <div class="hero__img" data-animation="bounceIn" data-delay=".4s">
                                <img src="assets2/img/hero/hero_man.png" alt="">
                            </div>
                        </div>
                        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-8">
                            <div class="hero__caption">
                                <span data-animation="fadeInRight" data-delay=".4s">60% Discount</span>
                                <h1 data-animation="fadeInRight" data-delay=".6s">Winter <br> Collection</h1>
                                <p data-animation="fadeInRight" data-delay=".8s">Best Cloth Collection By 2020!</p>
                                <!-- Hero-btn -->
                                <div class="hero__btn" data-animation="fadeInRight" data-delay="1s">
                                    <a href="/industries" class="btn hero-btn">Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- slider Area End-->
    <!-- Category Area Start-->
    <section class="category-area section-padding30">
        <div class="container-fluid">
            <!-- Section Tittle -->
            <div class="category-wrapper">
                <div id="row" style="padding-left: 50px;background: linear-gradient(-145deg, rgb(255, 255, 255), rgb(245, 129, 32) 30%, rgb(255, 172, 103));">
                    <div class="bar" style="color: white;">Kategori Produk</div>
                    <div class="brands-wrapper  row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div role="button" tabindex="0" class="eeq">
                            <div class="brand">
                                <img src="<?php echo e(asset('storage/products/' . $row->image)); ?>" alt="<?php echo e($row->name); ?>">
                            </div>
                            <a href="<?php echo e(url('/product_list/'. $row->slug)); ?>">
                                <h4><?php echo e($row->name); ?></h4>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Category Area End-->
    <!-- Latest Products Start -->
    <section class="latest-product-area padding-bottom">
        <div class="container">
            <div class="row product-btn d-flex justify-content-end align-items-end">

                <!-- Section Tittle -->
                <div class="col-xl-4 col-lg-5 col-md-5">
                    <div class="section-tittle mb-30">
                        <h2>Produk Terlaris</h2>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-5 col-md-5">
                    <div class="properties__button f-right">
                        <!--Nav Button  -->
                        <nav class="nav nav-pills nav-fill">
                            <a class="nav-item nav-link disabled" href="/terlaris">
                                <button type="button" class="btn btn-warning">All</button>
                            </a>
                        </nav>
                        <!--End Nav Button  -->
                    </div>
                </div>
            </div>
            <!-- Nav Card -->
            <div class="main-banner header-text">
                <div class="container-fluid">
                    <div class="owl-banner owl-carousel">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="item">
                            <img src="<?php echo e(asset('storage/products/' . $row->image)); ?>" alt="<?php echo e($row->name); ?>">
                            <div class="item-content">
                            </div>
                            <a href="<?php echo e(url('/single-product/'. $row->slug)); ?>">
                                <h4><?php echo e($row->name); ?></h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del></del>Rp <?php echo e(number_format($row->price)); ?></span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- End Nav Card -->
        </div>
    </section>
    <!-- Latest Products End -->
    <section class="latest-product-area padding-bottom">
        <div class="container">
            <div class="row product-btn d-flex justify-content-end align-items-end">
                <!-- Section Tittle -->
                <div class="col-xl-5 col-lg-4 col-md-4">
                    <div class="section-tittle mb-30">
                        <h2>Produk Terpopuler</h2>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-5 col-md-5">
                    <div class="properties__button f-right">
                        <!--Nav Button  -->
                        <nav class="nav nav-pills nav-fill">
                            <a class="nav-item nav-link disabled" href="/terpopuler">
                                <button type="button" class="btn btn-warning">All</button>
                            </a>
                        </nav>
                        <!--End Nav Button  -->
                    </div>
                </div>
            </div>
            <!-- Nav Card -->
            <div class="main-banner header-text">
                <div class="container-fluid">
                    <div class="owl-banner owl-carousel">
                        <div class="item">
                            <img src="assets2/img/categori/product1.png" alt="">
                            <div class="item-content">
                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product2.png" alt="">
                            <div class="item-content">
                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product3.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product4.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product5.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product6.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Nav Card -->
        </div>
    </section>

    <section class="latest-product-area padding-bottom">
        <div class="container">
            <div class="row product-btn d-flex justify-content-end align-items-end">
                <!-- Section Tittle -->
                <div class="col-xl-5 col-lg-4 col-md-4">
                    <div class="section-tittle mb-30">
                        <h2>Produk Terbaru</h2>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-5 col-md-5">
                    <div class="properties__button f-right">
                        <!--Nav Button  -->
                        <nav class="nav nav-pills nav-fill">
                            <a class="nav-item nav-link disabled" href="/terbaru">
                                <button type="button" class="btn btn-warning">All</button>
                            </a>
                        </nav>
                        <!--End Nav Button  -->
                    </div>
                </div>
            </div>
            <!-- Nav Card -->
            <div class="main-banner header-text">
                <div class="container-fluid">
                    <div class="owl-banner owl-carousel">
                        <div class="item">
                            <img src="assets2/img/categori/product1.png" alt="">
                            <div class="item-content">
                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product2.png" alt="">
                            <div class="item-content">
                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product3.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product4.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product5.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets2/img/categori/product6.png" alt="">
                            <div class="item-content">

                            </div>
                            <a href="/single-product">
                                <h4>Lorem ipsum dolor sit amet.</h4>
                            </a>
                            <div class="main-content">
                                <div class="meta-category">
                                    <span> <del>Rp500.00</del> Rp700.00 </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Nav Card -->
        </div>
    </section>
    <!-- Best Product Start -->
    <div class="best-product-area lf-padding">
        <div class="product-wrapper bg-height" style="background-image: url('assets2/img/categori/card.png')">
            <div class="container position-relative">
                <div class="row justify-content-between align-items-end">
                    <div class="product-man position-absolute  d-none d-lg-block">
                        <img src="assets2/img/categori/card-man.png" alt="">
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-2 d-none d-lg-block">
                        <div class="vertical-text">
                            <span>Manz</span>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-8">
                        <div class="best-product-caption">
                            <h2>Find The Best Product<br> from Our Shop</h2>
                            <p>Designers who are interesten creating state ofthe.</p>
                            <a href="#" class="black-btn">Shop Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Shape -->
        <div class="shape bounce-animate d-none d-md-block">
            <img src="assets2/img/categori/card-shape.png" alt="">
        </div>
    </div>
    <!-- Best Product End-->
    <!-- Best Collection Start -->
    <div class="best-collection-area section-padding2">
        <div class="container">
            <div class="row d-flex justify-content-between align-items-end">
                <!-- Left content -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="best-left-cap">
                        <h2>Best Collection of This Month</h2>
                        <p>Designers who are interesten crea.</p>
                        <a href="#" class="btn shop1-btn">Shop Now</a>
                    </div>
                    <div class="best-left-img mb-30 d-none d-sm-block">
                        <img src="assets2/img/collection/collection1.png" alt="">
                    </div>
                </div>
                <!-- Mid Img -->
                <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                    <div class="best-mid-img mb-30 ">
                        <img src="assets2/img/collection/collection2.png" alt="">
                    </div>
                </div>
                <!-- Riht Caption -->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="best-right-cap ">
                        <div class="best-single mb-30">
                            <div class="single-cap">
                                <h4>Menz Winter<br> Jacket</h4>
                            </div>
                            <div class="single-img">
                                <img src="assets2/img/collection/collection3.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="best-right-cap">
                        <div class="best-single mb-30">
                            <div class="single-cap active">
                                <h4>Menz Winter<br>Jacket</h4>
                            </div>
                            <div class="single-img">
                                <img src="assets2/img/collection/collection4.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="best-right-cap">
                        <div class="best-single mb-30">
                            <div class="single-cap">
                                <h4>Menz Winter<br> Jacket</h4>
                            </div>
                            <div class="single-img">
                                <img src="assets2/img/collection/collection5.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Best Collection End -->
    <!-- Latest Offers Start -->
    <div class="latest-wrapper lf-padding">
        <div class="latest-area latest-height d-flex align-items-center" data-background="assets2/img/collection/latest-offer.png">
            <div class="container">
                <div class="row d-flex align-items-center">
                    <div class="col-xl-5 col-lg-5 col-md-6 offset-xl-1 offset-lg-1">
                        <div class="latest-caption">
                            <h2>Get Our<br>Latest Offers News</h2>
                            <p>Subscribe news latter</p>
                        </div>
                    </div>
                    <div class="col-xl-5 col-lg-5 col-md-6 ">
                        <div class="latest-subscribe">
                            <form action="#">
                                <input type="email" placeholder="Your email here">
                                <button>Shop Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- man Shape -->
            <div class="man-shape">
                <img src="assets2/img/collection/latest-man.png" alt="">
            </div>
        </div>
    </div>
    <!-- Latest Offers End -->
    <!-- Shop Method Start-->
    <div class="shop-method-area section-padding30">
        <div class="container">
            <div class="row d-flex justify-content-between">
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="single-method mb-40">
                        <i class="ti-package"></i>
                        <h6>Free Shipping Method</h6>
                        <p>aorem ixpsacdolor sit ameasecur adipisicing elitsf edasd.</p>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="single-method mb-40">
                        <i class="ti-unlock"></i>
                        <h6>Secure Payment System</h6>
                        <p>aorem ixpsacdolor sit ameasecur adipisicing elitsf edasd.</p>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="single-method mb-40">
                        <i class="ti-reload"></i>
                        <h6>Secure Payment System</h6>
                        <p>aorem ixpsacdolor sit ameasecur adipisicing elitsf edasd.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Method End-->


</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Ecommerce/templates/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/Documents/MERN/Laravel/millennialad/resources/views/Ecommerce/index.blade.php ENDPATH**/ ?>