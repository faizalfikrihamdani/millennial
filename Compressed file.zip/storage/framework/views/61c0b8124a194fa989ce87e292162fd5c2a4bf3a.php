<footer>

       <!-- Footer Start-->
       <div id="brand" style="background:linear-gradient(-145deg, rgb(255, 255, 255), rgb(245, 129, 32) 30%, rgb(255, 172, 103));">
       <div class="footer-area footer-padding">
           <div class="container">
               <div class="row d-flex justify-content-between">
                   <div class="col-xl-3 col-lg-3 col-md-5 col-sm-6">
                      <div class="single-footer-caption mb-50">
                        <div class="single-footer-caption mb-30">
                             <!-- logo -->
                             <div class="font-weight-bold" style="font-size: 18px; margin-top: 15px; "> MillenniaL Tourse & Travel </div>
                            <div class="footer-tittle">
                                <div class="footer-pera">
                                    <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore.</div>
                               </div>
                            </div>
                        </div>
                      </div>
                   </div>
                  
                   
                   
               <!-- Footer bottom --> 
               <div class="row d-flex justify-content-between">
                <div class="col-xl-10 col-lg-10 col-md-10">
                    <div class="footer-copy-right">
             <div class="footer-tittle">
    <div>
        <div style="font-size: 17px;">Butuh Bantuan Kami? Ada di</div>
        <div class="font-weight-bold" style="font-size: 18px; margin-top: 15px; "> Senin - Jumat: 08.00 - 17.00 WIB</div>
        <div>Hari Besar Nasional Libur</div>
    </div>
      <ul class="footer__ul">
        <li class="footer__list">
            <div style="color: rgb(255, 255, 255); cursor: pointer;">
                <img src="assets2/img/png/comment.png" style="margin-right: 15px; height: 24px; width: 24px;">
                <span>Live Chat Millennial.com</span>
            </div>
        </li>
      <li class="footer__list">
            <div style="color: rgb(255, 255, 255); cursor: pointer;">
                <img src="assets2/img/png/email.png" style="margin-right: 15px; height: 24px; width: 24px;">
                <span>Support@Millennial.com</span>
            </div>
        </li>
        <li class="footer__list">
            <div style="color: rgb(255, 255, 255); cursor: pointer;">
                <img src="assets2/img/png/profile.png" style="margin-right: 15px; height: 24px; width: 24px;">
                <span>Ke: Millennial.com</span>
            </div>
        </li>
        <li class="footer__list">
            <div style="color: rgb(255, 255, 255); cursor: pointer;">
                <img src="assets2/img/png/help.png" style="margin-right: 15px; height: 24px; width: 24px;">
                <span>FAQ</span>
            </div>
        </li>
        <!-- social -->
            <li class="footer__list">
                <div class="footer-social">
                    <div>Ikuti Media Sosial Kami:</div>
                  <a href="#"><i class="fab fa-twitter"></i></a>
                  <a href="#"><i class="fab fa-facebook-f"></i></a>
                  <a href="#"><i class="fab fa-behance"></i></a>
                  <a href="#"><i class="fas fa-globe"></i></a>
                </div>
            </li>
        </ul>
  </div>
       <!-- Footer End-->

   </footer><?php /**PATH C:\xampp\htdocs\millennialad\resources\views/Ecommerce/footer.blade.php ENDPATH**/ ?>