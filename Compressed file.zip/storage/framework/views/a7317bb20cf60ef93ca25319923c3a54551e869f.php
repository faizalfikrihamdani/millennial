
<!-- <?php $__env->startSection('title','Home'); ?> -->
<?php $__env->startSection('utama'); ?>

    <main>
        <!-- slider Area Start-->
        <div class="slider-area ">
            <!-- Mobile Menu -->
            <a href="/kelas">
							<div class="single-slider slider-height d-flex align-items-center" data-background="assets2/img/komunitas/k1.jpg"></div>
						</a>
        </div></br>
        <!-- slider Area End-->
 <!-- slider Area Start-->
 <div class="slider-area ">
            <!-- Mobile Menu -->
        <a href="#">
            <div class="single-slider slider-height d-flex align-items-center" data-background="assets2/img/komunitas/k2.jpg"></div>
                </a>
        </div></br>
        <!-- slider Area End-->
         <!-- slider Area Start-->
         <div class="slider-area ">
            <!-- Mobile Menu -->
            <a href="/event">
            <div class="single-slider slider-height d-flex align-items-center" data-background="assets2/img/komunitas/k3.jpg">
            </div></a>
        </div>
        <!-- slider Area End-->
        <?php $__env->stopSection(); ?> 
<?php echo $__env->make('Ecommerce/templates/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/Documents/MERN/Laravel/millennialad/resources/views/Ecommerce/Komunitas.blade.php ENDPATH**/ ?>