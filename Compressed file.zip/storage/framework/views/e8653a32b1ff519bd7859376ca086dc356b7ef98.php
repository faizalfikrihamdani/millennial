
<!-- <?php $__env->startSection('title','Home'); ?> -->
<?php $__env->startSection('utama'); ?>

    <main>
         <!-- slider Area Start-->
         <div class="slider-area ">
            <!-- Mobile Menu -->
            <a href="#">
							<div class="slider-height" data-background="assets2/img/komunitas/k4.jpg"></div>
						</a>
        </div></br>
 <!-- product list part start-->
 <section class="about_us section-top-border">
        <div class="container">
            <!-- <div class="row justify-content-center"> -->
            <div class="col-md-3">
                    <!-- <div class="about_us_content">
                        <h5>Our Mission</h5>
                        <h3>Donec imperdiet congue orci consequat mattis. Donec rutrum porttitor sollicitudin. Pellentesque id dolor tempor sapien feugiat ultrices nec sed neque.</h3> -->
                        <div class="about_us_video">
                            <img src="assets2/img/komunitas/yt.jpg" alt="#" class="img-fluid">
                            <a class="about_video_icon popup-youtube" href="https://www.youtube.com/watch?v=0SgRV8GN-U0"></a>
                        </div>
                        <div class="col-md-13 mt-sm-25">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					    </div>
            </div>
        </div>
            
    </section></br>
    <!-- product list part end-->
        <?php $__env->stopSection(); ?> 
<?php echo $__env->make('Ecommerce/templates/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\millennialad\resources\views/Ecommerce/kelas.blade.php ENDPATH**/ ?>