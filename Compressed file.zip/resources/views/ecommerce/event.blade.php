@extends('templates/base')
<!-- @section('title','Home') -->
@section('utama')

    <main>
         <!-- slider Area Start-->
         <div class="slider-area ">
            <!-- Mobile Menu -->
            <a href="#">
							<div class="slider-height" data-background="assets/img/komunitas/k4.jpg"></div>
						</a>
        </div></br>

        <div class="whole-wrap">
		<div class="container box_1170">
			<div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>

            <div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>
            <div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>

            <div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>

            <div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>

            <div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>

            <div class="section-top-border">
				<div class="row">
					<div class="col-md-3">
						<img src="assets/img/komunitas/k5.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-md-9 mt-sm-20">
						<p><b>7 Cara Efektif Membuat Konten Promosi Yang Menarik.</b></p>
					</div>
				</div>
            </div>
</div>
</div>
        @endsection 