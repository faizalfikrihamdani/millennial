@extends('Ecommerce/templates/sticky')
<!-- @section('title','Home') -->
@section('utama')

<div class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="product_sidebar">

                </div>
            </div>
            <div class="col-md-8">
                <div class="product_list">
                    <div class="row">
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product6.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Cervical pillow for airplane
                                        car office nap pillow</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product2.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Geometric striped flower home classy decor</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product5.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Foam filling cotton slow rebound pillows</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product6.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Memory foam filling cotton Slow rebound pillows</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product1.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Memory foam filling cotton Slow rebound pillows</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product4.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Sleeping orthopedic sciatica Back Hip Joint Pain relief</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product5.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Memory foam filling cotton Slow rebound pillows</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product3.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Sleeping orthopedic sciatica Back Hip Joint Pain relief</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product2.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Geometric striped flower home classy decor</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="single_product_item">
                                <img src="assets2/img/categori/product1.png" alt="" class="img-fluid">
                                <h3> <a href="/single-product">Geometric striped flower home classy decor</a> </h3>
                                <p>From $5</p>
                            </div>
                        </div>
                    </div>
                    <div class="load_more_btn text-center">
                        <a href="#" class="btn_3">Load More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection