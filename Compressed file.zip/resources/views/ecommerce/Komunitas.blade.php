@extends('Ecommerce/templates/base')
<!-- @section('title','Home') -->
@section('utama')

    <main>
        <!-- slider Area Start-->
        <div class="slider-area ">
            <!-- Mobile Menu -->
            <a href="/kelas">
							<div class="single-slider slider-height d-flex align-items-center" data-background="assets2/img/komunitas/k1.jpg"></div>
						</a>
        </div></br>
        <!-- slider Area End-->
 <!-- slider Area Start-->
 <div class="slider-area ">
            <!-- Mobile Menu -->
        <a href="#">
            <div class="single-slider slider-height d-flex align-items-center" data-background="assets2/img/komunitas/k2.jpg"></div>
                </a>
        </div></br>
        <!-- slider Area End-->
         <!-- slider Area Start-->
         <div class="slider-area ">
            <!-- Mobile Menu -->
            <a href="/event">
            <div class="single-slider slider-height d-flex align-items-center" data-background="assets2/img/komunitas/k3.jpg">
            </div></a>
        </div>
        <!-- slider Area End-->
        @endsection 